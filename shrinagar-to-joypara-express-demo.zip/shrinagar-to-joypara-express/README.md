# শ্রীনগর টু জয়পাড়া এক্সপ্রেস — ওয়েবসাইট ডেমো

এটি একটি responsive front-end prototype, GitHub Pages বা Vercel-এ static site হিসেবে প্রকাশ করা যায়।

## ফাইল
- `index.html` — পেজের কাঠামো
- `style.css` — ডিজাইন ও মোবাইল responsive layout
- `app.js` — ওয়েলকাম স্ক্রিন, ভয়েস, ব্রাউজার-ভিত্তিক পোস্ট/ভোট ডেমো ও মানচিত্র

## Vercel-এ প্রকাশ
1. ZIP ফাইলটি extract করুন।
2. তিনটি ফাইল (`index.html`, `style.css`, `app.js`) একটি GitHub repository-তে upload করুন।
3. Vercel-এ গিয়ে **Add New → Project** নির্বাচন করে repository import করুন।
4. Framework Preset `Other` নির্বাচন করুন। Build Command ও Output Directory ফাঁকা/default রাখুন।
5. Deploy চাপুন।

## GitHub Pages-এ প্রকাশ
Repository → Settings → Pages → Deploy from a branch → `main` / `/ (root)` নির্বাচন করে Save করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি ডেমো, পূর্ণ production system নয়। পোস্ট ও ভোট একই browser-এর `localStorage`-এ থাকে; অন্য ব্যবহারকারীর কাছে যায় না। অ্যাডমিন প্যানেলটি demo-only, প্রকৃত authentication নেই। বাস্তব ব্যবহারের আগে backend/database, secure admin authentication, user accounts, server-side vote validation, moderation, privacy policy ও consent-based data handling যোগ করতে হবে।

- Welcome screen-এ “＋ ছবি দিন” দিয়ে ছবি বেছে নিলে প্রিভিউ এই ব্রাউজারেই দেখা যায়; ছবিটি সার্ভারে আপলোড হয় না।
- ভয়েস আপনার browser-এর built-in speech synthesis ব্যবহার করে; বাংলা কণ্ঠ ডিভাইসভেদে ভিন্ন হতে পারে।
- নামাজের বার্তাটি একটি স্থির demo banner। এটি এখনো স্থানীয় আযানের সময় হিসাব করে স্বয়ংক্রিয়ভাবে দেখায় না।
- মানচিত্রের জন্য ইন্টারনেট এবং OpenStreetMap tile service প্রয়োজন। চিহ্নিত অবস্থানগুলো আনুমানিক।
- কোনো API key বা secret এই ফাইলগুলোতে যোগ করবেন না।
